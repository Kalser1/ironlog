import Foundation
import UserNotifications

/// Ежедневные напоминания через UNUserNotificationCenter.
/// На iOS это надёжнее, чем AlarmManager: система сама повторяет UNCalendarNotificationTrigger.
final class ReminderManager: NSObject, ObservableObject, UNUserNotificationCenterDelegate {
    static let shared = ReminderManager()

    @Published var notificationsAuthorized: Bool = false

    private let center = UNUserNotificationCenter.current()
    private var scheduledIdentifiers: [String] = []

    override init() {
        super.init()
        center.delegate = self
        refreshAuthorization()
    }

    func refreshAuthorization() {
        center.getNotificationSettings { [weak self] settings in
            DispatchQueue.main.async {
                self?.notificationsAuthorized = settings.authorizationStatus == .authorized
            }
        }
    }

    func refreshAuthorizationAndSync(reminders: [Reminder]) {
        center.getNotificationSettings { [weak self] settings in
            DispatchQueue.main.async {
                self?.notificationsAuthorized = settings.authorizationStatus == .authorized
                self?.sync(reminders: reminders)
            }
        }
    }

    func requestAuthorization(reminders: [Reminder] = []) {
        center.requestAuthorization(options: [.alert, .sound, .badge]) { [weak self] granted, _ in
            DispatchQueue.main.async {
                self?.notificationsAuthorized = granted
                self?.sync(reminders: reminders)
            }
        }
    }

    /// Полная синхронизация: удаляем все наши повторяющиеся напоминания и ставим заново.
    func sync(reminders: [Reminder]) {
        center.removePendingNotificationRequests(withIdentifiers: scheduledIdentifiers)
        scheduledIdentifiers = []
        guard notificationsAuthorized else { return }
        for reminder in reminders where reminder.enabled {
            let content = UNMutableNotificationContent()
            content.title = "Напоминание · \(reminder.timeLabel)"
            content.body = reminder.text
            content.sound = .default
            content.categoryIdentifier = "daily_reminders_v1"

            var components = DateComponents()
            components.hour = reminder.hour
            components.minute = reminder.minute
            let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
            let id = identifier(for: reminder.id)
            scheduledIdentifiers.append(id)
            let request = UNNotificationRequest(
                identifier: id, content: content, trigger: trigger
            )
            center.add(request) { error in
                if let error { print("Reminder schedule error: \(error)") }
            }
        }
    }

    func scheduleRestTimer(seconds: Int) {
        let content = UNMutableNotificationContent()
        content.title = "Отдых закончился"
        content.body = "Пора к следующему подходу."
        content.sound = .default
        content.categoryIdentifier = "rest_timer_v2"
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: Double(max(1, seconds)), repeats: false)
        let request = UNNotificationRequest(
            identifier: "rest_timer", content: content, trigger: trigger
        )
        center.add(request, withCompletionHandler: nil)
    }

    func cancelRestTimer() {
        center.removePendingNotificationRequests(withIdentifiers: ["rest_timer"])
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .badge])
    }

    private func identifier(for id: Int64) -> String { "reminder_\(id)" }
}
