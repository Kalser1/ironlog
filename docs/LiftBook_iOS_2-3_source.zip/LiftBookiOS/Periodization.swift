import Foundation

/// Точный порт логики периодизации из Android-версии (data/Periodization.kt).
enum Periodization {
    static let dayMs: Int64 = 24 * 60 * 60 * 1000
    static let weekMs: Int64 = 7 * dayMs

    static let defaultPhases: [CyclePhaseConfig] = [
        CyclePhaseConfig(id: "volume", name: "Объёмная", weeks: 1, weightFactor: 1.0, repsDelta: 2, setsDelta: 1),
        CyclePhaseConfig(id: "strength", name: "Силовая", weeks: 1, weightFactor: 1.10, repsDelta: -2, setsDelta: 0),
        CyclePhaseConfig(id: "deload", name: "Разгрузочная", weeks: 1, weightFactor: 0.85, repsDelta: -2, setsDelta: -1)
    ]

    static func normalize(_ phases: [CyclePhaseConfig]) -> [CyclePhaseConfig] {
        let valid = phases.filter { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty }
        return valid.isEmpty ? defaultPhases : valid
    }

    static func totalWeeks(_ phases: [CyclePhaseConfig]) -> Int {
        phases.reduce(0) { $0 + max(1, $1.weeks) }
    }

    static func weekIndex(cycleStartAt: Int64, now: Int64 = nowMs(), phases: [CyclePhaseConfig]) -> Int {
        let total = totalWeeks(phases)
        guard cycleStartAt > 0, total > 0 else { return 0 }
        let elapsed = max(0, now - cycleStartAt)
        return Int(elapsed / weekMs) % total
    }

    static func phaseForWeek(_ weekIndex: Int, phases: [CyclePhaseConfig]) -> CyclePhaseConfig {
        let list = normalize(phases)
        let total = totalWeeks(list)
        guard total > 0 else { return list.first ?? defaultPhases[0] }
        var remaining = ((weekIndex % total) + total) % total
        for phase in list {
            let weeks = max(1, phase.weeks)
            if remaining < weeks { return phase }
            remaining -= weeks
        }
        return list.last ?? defaultPhases[0]
    }

    static func phaseStartWeek(_ weekIndex: Int, phases: [CyclePhaseConfig]) -> Int {
        let list = normalize(phases)
        let total = totalWeeks(list)
        var remaining = ((weekIndex % total) + total) % total
        var acc = 0
        for phase in list {
            let weeks = max(1, phase.weeks)
            if remaining < weeks { return acc }
            remaining -= weeks
            acc += weeks
        }
        return acc
    }

    static func phaseStartAt(cycleStartAt: Int64, now: Int64 = nowMs(), phases: [CyclePhaseConfig]) -> Int64 {
        let list = normalize(phases)
        let total = totalWeeks(list)
        guard total > 0 else { return cycleStartAt }
        let elapsed = max(0, now - cycleStartAt)
        let cyclesPassed = elapsed / weekMs / Int64(total)
        let index = weekIndex(cycleStartAt: cycleStartAt, now: now, phases: list)
        return cycleStartAt + (cyclesPassed * Int64(total) + Int64(phaseStartWeek(index, phases: list))) * weekMs
    }

    static func daysLeftInPhase(cycleStartAt: Int64, now: Int64 = nowMs(), phases: [CyclePhaseConfig]) -> Int {
        guard cycleStartAt > 0 else { return 7 }
        let list = normalize(phases)
        let index = weekIndex(cycleStartAt: cycleStartAt, now: now, phases: list)
        let phase = phaseForWeek(index, phases: list)
        let weeks = max(1, phase.weeks)
        let start = phaseStartAt(cycleStartAt: cycleStartAt, now: now, phases: list)
        let leftMs = max(0, start + Int64(weeks) * weekMs - now)
        return Int((leftMs + dayMs - 1) / dayMs).clamped(to: 0...(weeks * 7))
    }

    static func startOfDay(_ timestamp: Int64 = nowMs()) -> Int64 {
        var cal = Calendar.current
        cal.timeZone = .current
        let date = Date(timeIntervalSince1970: Double(timestamp) / 1000.0)
        let components = cal.dateComponents([.year, .month, .day], from: date)
        return Int64(cal.date(from: components)!.timeIntervalSince1970 * 1000)
    }

    // MARK: Корректировка рабочих параметров

    static func adjustWeight(_ baseWeight: String, phase: CyclePhaseConfig) -> String {
        let trimmed = baseWeight.trimmingCharacters(in: .whitespaces)
            .trimmingCharacters(in: CharacterSet(charactersIn: ",."))
        if trimmed.isEmpty { return "" }
        let normalized = trimmed.replacingOccurrences(of: ",", with: ".")
        guard let value = Double(normalized), value > 0 else { return trimmed }
        return formatWeightValue(roundToStep(value * phase.weightFactor))
    }

    static func adjustReps(_ base: Int, phase: CyclePhaseConfig) -> Int {
        (base + phase.repsDelta).clamped(to: 1...100)
    }

    static func adjustSets(_ base: Int, phase: CyclePhaseConfig) -> Int {
        (base + phase.setsDelta).clamped(to: 1...20)
    }

    static func roundToStep(_ value: Double, step: Double = 2.5) -> Double {
        guard value > 0, step > 0 else { return 0 }
        return (value / step).rounded() * step
    }

    static func formatWeightValue(_ value: Double) -> String {
        if value == floor(value) { return String(format: "%.0f", value) }
        return String(format: "%.1f", locale: Locale(identifier: "en_US_POSIX"), value)
    }

    // MARK: Завершённость фазы и автопрогрессия

    static func isPhaseCompleted(_ exercise: LoggedExercise) -> Bool {
        guard let targetWeight = exercise.targetWeight, let targetReps = exercise.targetReps,
              !exercise.sets.isEmpty else { return false }
        return exercise.sets.allSatisfy { $0.weight + 0.001 >= targetWeight && $0.reps >= targetReps }
    }

    static func progressionSuggestion(
        history: [Workout],
        routineId: Int64?,
        phase: CyclePhaseConfig,
        cycleStartAt: Int64,
        phases: [CyclePhaseConfig],
        exerciseName: String
    ) -> ProgressionSuggestion? {
        guard cycleStartAt > 0 else { return nil }
        let now = nowMs()
        let currentPhaseStart = phaseStartAt(cycleStartAt: cycleStartAt, now: now, phases: phases)

        let sorted = history.sorted { $0.finishedAt > $1.finishedAt }
        for workout in sorted {
            guard workout.routineId == routineId,
                  workout.phase == phase.id,
                  workout.finishedAt < currentPhaseStart else { continue }
            guard let exercise = workout.exercises.first(where: { $0.name == exerciseName }),
                  isPhaseCompleted(exercise) else { continue }
            let previousWeight = exercise.sets.map(\.weight).max() ?? 0
            guard previousWeight > 0 else { continue }
            let target = exercise.targetWeight ?? previousWeight
            let suggested = roundToStep(max(previousWeight, target) + 2.5)
            guard suggested > previousWeight else { continue }
            return ProgressionSuggestion(
                exerciseName: exerciseName,
                phaseName: phase.name,
                targetReps: exercise.targetReps ?? 0,
                previousWeight: previousWeight,
                suggestedWeight: suggested,
                basedOnDate: workout.finishedAt
            )
        }
        return nil
    }

    static func adjustmentLabel(_ phase: CyclePhaseConfig) -> String {
        let percent = Int((phase.weightFactor - 1.0) * 100.0.rounded())
        var parts: [String] = []
        if percent == 0 { parts.append("Вес базовый") }
        else if percent > 0 { parts.append("Вес +\(percent)%") }
        else { parts.append("Вес −\(-percent)%") }
        if phase.repsDelta != 0 { parts.append("повторения \(signed(phase.repsDelta))") }
        if phase.setsDelta != 0 { parts.append("подходы \(signed(phase.setsDelta))") }
        if phase.weeks > 1 { parts.append("\(phase.weeks) нед.") }
        return parts.joined(separator: " · ")
    }

    static func signed(_ value: Int) -> String {
        value >= 0 ? "+\(value)" : "−\(-value)"
    }

    static func nowMs() -> Int64 {
        Int64(Date().timeIntervalSince1970 * 1000)
    }
}

extension Comparable {
    func clamped(to range: ClosedRange<Self>) -> Self {
        if self < range.lowerBound { return range.lowerBound }
        if self > range.upperBound { return range.upperBound }
        return self
    }
}
