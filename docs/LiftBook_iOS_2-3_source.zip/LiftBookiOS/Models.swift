import Foundation

// MARK: - Каталог упражнений

struct Exercise: Codable, Identifiable, Hashable {
    let id = UUID()
    var name: String
    var group: String
    var equipment: String
    var level: String
    var desc: String
    var custom: Bool = false

    enum CodingKeys: String, CodingKey {
        case name, group, equipment, level, desc, custom
    }

    init(name: String, group: String, equipment: String, level: String, desc: String, custom: Bool = false) {
        self.name = name
        self.group = group
        self.equipment = equipment
        self.level = level
        self.desc = desc
        self.custom = custom
    }
}

enum ExerciseCatalog {
    static let customGroup = "Своё"
    static let groupOrder = ["Грудь", "Руки", "Спина", "Ноги", "Плечи", "Корпус", "Фулбоди", "Кардио", customGroup]

    static func load() -> [Exercise] {
        guard let url = Bundle.main.url(forResource: "exercises", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let items = try? JSONDecoder().decode([Exercise].self, from: data) else {
            return []
        }
        return items.sorted { groupIndex($0.group) < groupIndex($1.group) }
    }

    static func groupIndex(_ group: String) -> Int {
        let i = groupOrder.firstIndex(of: group) ?? 99
        return i
    }
}

// MARK: - Завершённая тренировка

struct LoggedSet: Codable, Hashable {
    var weight: Double
    var reps: Int
}

struct LoggedExercise: Codable, Hashable {
    var name: String
    var group: String
    var sets: [LoggedSet]
    var note: String = ""
    var targetReps: Int? = nil
    var targetWeight: Double? = nil

    var volume: Double { sets.reduce(0) { $0 + $1.weight * Double($1.reps) } }
    var bestWeight: Double { sets.map(\.weight).max() ?? 0 }
    var totalReps: Int { sets.reduce(0) { $0 + $1.reps } }
}

struct Workout: Codable, Identifiable, Hashable {
    var id: Int64
    var startedAt: Int64
    var finishedAt: Int64
    var exercises: [LoggedExercise]
    var phase: String? = nil
    var routineId: Int64? = nil
    var programId: Int64? = nil

    var volume: Double { exercises.reduce(0) { $0 + $1.volume } }
    var totalSets: Int { exercises.reduce(0) { $0 + $1.sets.count } }
    var totalReps: Int { exercises.reduce(0) { $0 + $1.totalReps } }
    var durationMs: Int64 { max(0, finishedAt - startedAt) }
}

// MARK: - Активная тренировка

struct ActiveSet: Codable, Hashable {
    var weight: String = ""
    var reps: String = ""
    var done: Bool = false
}

struct ActiveExercise: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var group: String
    var sets: [ActiveSet]
    var note: String = ""
    var supersetId: String? = nil
    var targetReps: Int? = nil
    var targetWeight: Double? = nil

    enum CodingKeys: String, CodingKey {
        case name, group, sets, note, supersetId, targetReps, targetWeight
    }
}

struct ActiveWorkout: Codable {
    var startedAt: Int64
    var exercises: [ActiveExercise]
    var routineId: Int64? = nil
    var routineName: String? = nil
    var routineComment: String? = nil
    var phase: CyclePhaseConfig? = nil
    var programId: Int64? = nil
    var cycleStartAt: Int64? = nil
    var cyclePhases: [CyclePhaseConfig] = Periodization.defaultPhases
}

// MARK: - Рутины и программы

struct RoutineExercise: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var group: String = ""
    var sets: Int = 3
    var reps: Int = 10
    var weight: String = ""
    var comment: String = ""
    var supersetId: String? = nil

    enum CodingKeys: String, CodingKey {
        case name, group, sets, reps, weight, comment, supersetId
    }
}

struct Routine: Codable, Identifiable, Hashable {
    var id: Int64
    var name: String
    var comment: String = ""
    var exercises: [RoutineExercise] = []

    var totalSets: Int { exercises.reduce(0) { $0 + max(0, $1.sets) } }
}

struct WorkoutProgram: Codable, Identifiable, Hashable {
    var id: Int64
    var name: String
    var createdAt: Int64
    var comment: String = ""
    var routines: [Routine] = []
    var cycleEnabled: Bool = false
    var cycleStartAt: Int64 = 0
    var cyclePhases: [CyclePhaseConfig] = Periodization.defaultPhases

    var exerciseCount: Int { routines.reduce(0) { $0 + $1.exercises.count } }
    var totalSets: Int { routines.reduce(0) { $0 + $1.totalSets } }
}

// MARK: - Периодизация

struct CyclePhaseConfig: Codable, Identifiable, Hashable {
    var id: String
    var name: String
    var weeks: Int
    var weightFactor: Double
    var repsDelta: Int
    var setsDelta: Int
}

struct ProgressionSuggestion {
    var exerciseName: String
    var phaseName: String
    var targetReps: Int
    var previousWeight: Double
    var suggestedWeight: Double
    var basedOnDate: Int64
}

// MARK: - Напоминания

struct Reminder: Codable, Identifiable, Hashable {
    var id: Int64
    var text: String
    var hour: Int
    var minute: Int
    var enabled: Bool = true

    var timeLabel: String { String(format: "%02d:%02d", hour, minute) }
}

// MARK: - Настройки

enum Accent: String, Codable, CaseIterable {
    case lime = "LIME"
    case blue = "BLUE"
    case orange = "ORANGE"
    case pink = "PINK"
    case purple = "PURPLE"

    var label: String {
        switch self {
        case .lime: return "Лайм"
        case .blue: return "Небо"
        case .orange: return "Апельсин"
        case .pink: return "Роза"
        case .purple: return "Лаванда"
        }
    }
}

enum ThemeMode: String, Codable, CaseIterable {
    case light = "LIGHT"
    case handwritten = "HANDWRITTEN"
    case handwrittenDark = "HANDWRITTEN_DARK"
    case dark = "DARK"
    case amoled = "AMOLED"

    var label: String {
        switch self {
        case .light: return "Бумага"
        case .handwritten: return "Синий почерк"
        case .handwrittenDark: return "Чёрный почерк"
        case .dark: return "Тёмная доска"
        case .amoled: return "Чёрный скетчбук"
        }
    }

    var description: String {
        switch self {
        case .light: return "Тёплый лист в линейку"
        case .handwritten: return "Ручка на тетрадном листе"
        case .handwrittenDark: return "Белые чернила на чёрном листе"
        case .dark: return "Мел на зелёной доске"
        case .amoled: return "Белый карандаш на чёрном"
        }
    }

    var isDark: Bool {
        switch self {
        case .handwrittenDark, .dark, .amoled: return true
        default: return false
        }
    }
}

enum HandInkColor: String, Codable, CaseIterable {
    case blue = "BLUE"
    case black = "BLACK"
    case pencil = "PENCIL"

    var label: String {
        switch self {
        case .blue: return "Синий"
        case .black: return "Чёрный"
        case .pencil: return "Серый"
        }
    }
}

struct AppSettings: Codable {
    var accent: Accent = .lime
    var restSeconds: Int = 150
    var theme: ThemeMode = .light
    var inkColor: HandInkColor = .blue
    var shortRestSeconds: Int = 60
    var shareCodeOnly: Bool = false

    enum CodingKeys: String, CodingKey {
        case accent, theme, inkColor
        case restSeconds = "rest_seconds"
        case shortRestSeconds = "short_rest_seconds"
        case shareCodeOnly = "share_code_only"
    }
}

// MARK: - Всё состояние приложения (один JSON-файл, аналог ironlog_store)

struct AppState: Codable {
    var history: [Workout] = []
    var active: ActiveWorkout? = nil
    var customExercises: [Exercise] = []
    var programs: [WorkoutProgram] = []
    var reminders: [Reminder] = []
    var settings: AppSettings = AppSettings()

    init() {}

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        history = (try? c.decode([Workout].self, forKey: .history)) ?? []
        active = try? c.decode(ActiveWorkout.self, forKey: .active)
        customExercises = (try? c.decode([Exercise].self, forKey: .customExercises)) ?? []
        programs = (try? c.decode([WorkoutProgram].self, forKey: .programs)) ?? []
        reminders = (try? c.decode([Reminder].self, forKey: .reminders)) ?? []
        settings = (try? c.decode(AppSettings.self, forKey: .settings)) ?? AppSettings()
    }
}
