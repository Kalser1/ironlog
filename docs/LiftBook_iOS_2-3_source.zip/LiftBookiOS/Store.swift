import Foundation
import SwiftUI
import UserNotifications

/// Единое хранилище состояния. Аналог AppViewModel + WorkoutStore + SettingsStore + ReminderStore.
final class Store: ObservableObject {
    @Published var state: AppState

    let builtinExercises: [Exercise] = ExerciseCatalog.load()

    private let fileURL: URL = {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("ironlog_store.json")
    }()

    init() {
        if let data = try? Data(contentsOf: Self.storeURL()),
           let decoded = try? JSONDecoder().decode(AppState.self, from: data) {
            state = decoded
        } else {
            state = AppState()
        }
        state.history.sort { $0.finishedAt > $1.finishedAt }
        normalizeState()
    }

    private static func storeURL() -> URL {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("ironlog_store.json")
    }

    func save() {
        do {
            let data = try JSONEncoder().encode(state)
            try data.write(to: fileURL, options: .atomic)
        } catch {
            print("LiftBook save error: \(error)")
        }
    }

    private func normalizeState() {
        state.reminders = state.reminders.compactMap { r in
            let text = r.text.trimmingCharacters(in: .whitespaces)
            guard !text.isEmpty else { return nil }
            var copy = r
            copy.text = text
            copy.hour = r.hour.clamped(to: 0...23)
            copy.minute = r.minute.clamped(to: 0...59)
            return copy
        }.sorted {
            if $0.hour != $1.hour { return $0.hour < $1.hour }
            if $0.minute != $1.minute { return $0.minute < $1.minute }
            return $0.id < $1.id
        }
        state.settings.restSeconds = state.settings.restSeconds.clamped(to: 15...900)
        state.settings.shortRestSeconds = state.settings.shortRestSeconds.clamped(to: 15...900)
    }

    // MARK: - Каталог

    var exercises: [Exercise] {
        (builtinExercises + state.customExercises).sorted {
            ExerciseCatalog.groupIndex($0.group) < ExerciseCatalog.groupIndex($1.group)
        }
    }

    var groups: [String] { ExerciseCatalog.groupOrder }

    func exercise(named name: String) -> Exercise? {
        exercises.first { $0.name.caseInsensitiveCompare(name) == .orderedSame }
    }

    func addCustomExercise(_ exercise: Exercise) -> Bool {
        let trimmed = exercise.name.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return false }
        if exercises.contains(where: { $0.name.caseInsensitiveCompare(trimmed) == .orderedSame }) {
            return false
        }
        var copy = exercise
        copy.name = trimmed
        copy.custom = true
        state.customExercises.append(copy)
        save()
        return true
    }

    func updateCustomExercise(_ exercise: Exercise) -> Bool {
        guard let idx = state.customExercises.firstIndex(where: { $0.id == exercise.id }) else { return false }
        let trimmed = exercise.name.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return false }
        if exercises.contains(where: { $0.id != exercise.id && $0.name.caseInsensitiveCompare(trimmed) == .orderedSame }) {
            return false
        }
        var copy = exercise
        copy.name = trimmed
        copy.custom = true
        state.customExercises[idx] = copy
        save()
        return true
    }

    func deleteCustomExercise(_ id: UUID) {
        guard let removed = state.customExercises.first(where: { $0.id == id }) else { return }
        state.customExercises.removeAll { $0.id == id }
        for pi in state.programs.indices {
            for ri in state.programs[pi].routines.indices {
                state.programs[pi].routines[ri].exercises.removeAll { $0.name == removed.name }
            }
        }
        if var active = state.active {
            active.exercises.removeAll { $0.name == removed.name }
            state.active = active
        }
        save()
    }

    // MARK: - Тренировка

    func startWorkout() {
        let active = ActiveWorkout(startedAt: Periodization.nowMs(), exercises: [])
        state.active = active
        save()
    }

    func lastWeight(for name: String) -> String? {
        for workout in state.history {
            if let ex = workout.exercises.first(where: { $0.name == name }),
               let w = ex.sets.map(\.weight).filter({ $0 > 0 }).last {
                return formatWeight(w)
            }
        }
        return nil
    }

    func startWorkoutFromRoutine(programId: Int64, routineId: Int64) {
        guard let program = state.programs.first(where: { $0.id == programId }),
              let routine = program.routines.first(where: { $0.id == routineId }) else { return }

        var phase: CyclePhaseConfig? = nil
        var cycleStart: Int64? = nil
        if program.cycleEnabled && program.cycleStartAt > 0 {
            let week = Periodization.weekIndex(cycleStartAt: program.cycleStartAt, phases: program.cyclePhases)
            phase = Periodization.phaseForWeek(week, phases: program.cyclePhases)
            cycleStart = program.cycleStartAt
        }

        var activeExercises: [ActiveExercise] = []
        for entry in routine.exercises {
            let group = entry.group.isEmpty ? (exercise(named: entry.name)?.group ?? "") : entry.group
            let base = entry.weight.trimmingCharacters(in: CharacterSet(charactersIn: ",."))
            let baseWeight = base.isEmpty ? (lastWeight(for: entry.name) ?? "") : base
            let weight: String
            let reps: Int
            let setCount: Int
            if let phase {
                weight = Periodization.adjustWeight(baseWeight, phase: phase)
                reps = Periodization.adjustReps(entry.reps, phase: phase)
                setCount = Periodization.adjustSets(entry.sets, phase: phase)
            } else {
                weight = baseWeight
                reps = entry.reps
                setCount = entry.sets
            }
            let sets = (0..<setCount.clamped(to: 1...20)).map { _ in
                ActiveSet(weight: weight, reps: String(reps), done: false)
            }
            activeExercises.append(ActiveExercise(
                name: entry.name, group: group, sets: sets, note: "",
                supersetId: entry.supersetId,
                targetReps: phase != nil ? reps : nil,
                targetWeight: phase != nil ? Double(weight.replacingOccurrences(of: ",", with: ".")) : nil
            ))
        }

        state.active = ActiveWorkout(
            startedAt: Periodization.nowMs(),
            exercises: activeExercises,
            routineId: routine.id,
            routineName: routine.name,
            routineComment: routine.comment,
            phase: phase,
            programId: programId,
            cycleStartAt: cycleStart,
            cyclePhases: program.cyclePhases
        )
        save()
    }

    func finishWorkout() -> Bool {
        guard var active = state.active, !active.exercises.isEmpty else { return false }
        let finishedAt = Periodization.nowMs()
        var logged: [LoggedExercise] = []
        for ex in active.exercises {
            let sets = ex.sets.compactMap { s -> LoggedSet? in
                let w = Double(s.weight.replacingOccurrences(of: ",", with: ".")) ?? 0
                let r = Int(s.reps) ?? 0
                guard w > 0 || r > 0 else { return nil }
                return LoggedSet(weight: w.clamped(to: 0...5000), reps: r.clamped(to: 0...1000))
            }
            logged.append(LoggedExercise(
                name: ex.name, group: ex.group, sets: sets, note: ex.note,
                targetReps: ex.targetReps, targetWeight: ex.targetWeight
            ))
        }
        let workout = Workout(
            id: finishedAt, startedAt: active.startedAt, finishedAt: finishedAt,
            exercises: logged, phase: active.phase?.id,
            routineId: active.routineId, programId: active.programId
        )
        state.history.append(workout)
        state.history.sort { $0.finishedAt > $1.finishedAt }

        if active.phase == nil {
            rememberRoutineWeights(from: active)
        }
        state.active = nil
        save()
        return true
    }

    private func rememberRoutineWeights(from active: ActiveWorkout) {
        guard let programId = active.programId, let routineId = active.routineId else { return }
        guard let pi = state.programs.firstIndex(where: { $0.id == programId }),
              let ri = state.programs[pi].routines.firstIndex(where: { $0.id == routineId }) else { return }
        for (i, var entry) in state.programs[pi].routines[ri].exercises.enumerated() {
            if let activeEx = active.exercises.first(where: { $0.name == entry.name }),
               let first = activeEx.sets.first {
                entry.weight = first.weight
                state.programs[pi].routines[ri].exercises[i] = entry
            }
        }
    }

    func progressionHint(for exerciseName: String) -> ProgressionSuggestion? {
        guard let active = state.active, let phase = active.phase,
              let cycleStart = active.cycleStartAt else { return nil }
        guard let suggestion = Periodization.progressionSuggestion(
            history: state.history, routineId: active.routineId, phase: phase,
            cycleStartAt: cycleStart, phases: active.cyclePhases, exerciseName: exerciseName
        ) else { return nil }
        if let ex = active.exercises.first(where: { $0.name == exerciseName }) {
            let allAtLeast = ex.sets.allSatisfy { s in
                (Double(s.weight.replacingOccurrences(of: ",", with: ".")) ?? 0) + 0.001 >= suggestion.suggestedWeight
            }
            if allAtLeast { return nil }
        }
        return suggestion
    }

    func applyProgression(_ suggestion: ProgressionSuggestion) {
        guard var active = state.active else { return }
        if let idx = active.exercises.firstIndex(where: { $0.name == suggestion.exerciseName }) {
            let w = Periodization.formatWeightValue(suggestion.suggestedWeight)
            for i in active.exercises[idx].sets.indices {
                active.exercises[idx].sets[i].weight = w
                active.exercises[idx].sets[i].reps = String(suggestion.targetReps)
            }
            state.active = active
            save()
        }
    }

    func currentPhaseInfo() -> (phase: CyclePhaseConfig, week: Int, total: Int, daysLeft: Int)? {
        guard let active = state.active, let phase = active.phase,
              let cycleStart = active.cycleStartAt else { return nil }
        let week = Periodization.weekIndex(cycleStartAt: cycleStart, phases: active.cyclePhases)
        return (
            phase: phase,
            week: week + 1,
            total: Periodization.totalWeeks(active.cyclePhases),
            daysLeft: Periodization.daysLeftInPhase(cycleStartAt: cycleStart, phases: active.cyclePhases)
        )
    }

    // MARK: - Программы

    func createProgram(name: String) -> Int64 {
        let id = Periodization.nowMs()
        state.programs.append(WorkoutProgram(id: id, name: name, createdAt: id))
        save()
        return id
    }

    func deleteProgram(_ id: Int64) {
        state.programs.removeAll { $0.id == id }
        save()
    }

    func setProgramCycle(_ id: Int64, enabled: Bool) {
        guard let idx = state.programs.firstIndex(where: { $0.id == id }) else { return }
        if enabled && state.programs[idx].cycleStartAt <= 0 {
            state.programs[idx].cycleStartAt = Periodization.startOfDay()
        }
        state.programs[idx].cycleEnabled = enabled
        save()
    }

    func restartProgramCycle(_ id: Int64) {
        guard let idx = state.programs.firstIndex(where: { $0.id == id }) else { return }
        state.programs[idx].cycleEnabled = true
        state.programs[idx].cycleStartAt = Periodization.startOfDay()
        save()
    }

    func saveProgramCyclePhases(_ id: Int64, phases: [CyclePhaseConfig]) {
        guard let idx = state.programs.firstIndex(where: { $0.id == id }) else { return }
        state.programs[idx].cyclePhases = Periodization.normalize(phases)
        save()
    }

    func resetProgramCyclePhases(_ id: Int64) {
        guard let idx = state.programs.firstIndex(where: { $0.id == id }) else { return }
        state.programs[idx].cyclePhases = Periodization.defaultPhases
        save()
    }

    // MARK: - Напоминания

    func addReminder(text: String, hour: Int, minute: Int) {
        let trimmed = text.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        var id = Periodization.nowMs()
        while state.reminders.contains(where: { $0.id == id }) { id += 1 }
        state.reminders.append(Reminder(
            id: id, text: trimmed, hour: hour.clamped(to: 0...23), minute: minute.clamped(to: 0...59)
        ))
        normalizeState()
        save()
        ReminderManager.shared.sync(reminders: state.reminders)
    }

    func updateReminder(id: Int64, text: String, hour: Int, minute: Int) {
        guard let idx = state.reminders.firstIndex(where: { $0.id == id }) else { return }
        let trimmed = text.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        state.reminders[idx].text = trimmed
        state.reminders[idx].hour = hour.clamped(to: 0...23)
        state.reminders[idx].minute = minute.clamped(to: 0...59)
        normalizeState()
        save()
        ReminderManager.shared.sync(reminders: state.reminders)
    }

    func setReminderEnabled(_ id: Int64, enabled: Bool) {
        guard let idx = state.reminders.firstIndex(where: { $0.id == id }) else { return }
        state.reminders[idx].enabled = enabled
        save()
        ReminderManager.shared.sync(reminders: state.reminders)
    }

    func removeReminder(_ id: Int64) {
        state.reminders.removeAll { $0.id == id }
        save()
        ReminderManager.shared.sync(reminders: state.reminders)
    }

    // MARK: - Настройки

    func setAccent(_ value: Accent) { state.settings.accent = value; save() }
    func setTheme(_ value: ThemeMode) { state.settings.theme = value; save() }
    func setInkColor(_ value: HandInkColor) { state.settings.inkColor = value; save() }
    func setRestSeconds(_ value: Int) { state.settings.restSeconds = value.clamped(to: 15...900); save() }
    func setShortRestSeconds(_ value: Int) { state.settings.shortRestSeconds = value.clamped(to: 15...900); save() }
    func setShareCodeOnly(_ value: Bool) { state.settings.shareCodeOnly = value; save() }

    // MARK: - Код обмена

    func importShareCode(_ raw: String) -> ImportedPayload? {
        guard let payload = ShareCode.decode(raw) else { return nil }
        var added = 0
        switch payload {
        case .workout(let workout, let meta):
            for (name, info) in meta {
                if exercise(named: name) == nil {
                    state.customExercises.append(Exercise(
                        name: name, group: ExerciseCatalog.customGroup,
                        equipment: info.equipment, level: info.level, desc: info.desc, custom: true
                    ))
                    added += 1
                }
            }
            var copy = workout
            copy.id = Periodization.nowMs()
            state.history.append(copy)
            state.history.sort { $0.finishedAt > $1.finishedAt }
        case .program(let program, let meta):
            for (name, info) in meta {
                if exercise(named: name) == nil {
                    state.customExercises.append(Exercise(
                        name: name, group: ExerciseCatalog.customGroup,
                        equipment: info.equipment, level: info.level, desc: info.desc, custom: true
                    ))
                    added += 1
                }
            }
            var copy = program
            copy.id = Periodization.nowMs()
            copy.createdAt = copy.id
            for ri in copy.routines.indices {
                copy.routines[ri].id = Periodization.nowMs() + Int64(ri)
            }
            state.programs.append(copy)
        }
        save()
        return ImportedPayload(payload: payload, addedToCustom: added)
    }
}

struct ImportedPayload {
    let payload: SharedPayload
    let addedToCustom: Int
}
