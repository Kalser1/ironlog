import SwiftUI
import CoreText

/// Порт палитры и «бумажной» стилистики Android-версии.
enum LiftTheme {
    static func paper(_ theme: ThemeMode) -> Color {
        switch theme {
        case .light: return Color(red: 0.98, green: 0.965, blue: 0.91)
        case .handwritten: return Color(red: 0.93, green: 0.94, blue: 0.88)
        case .handwrittenDark: return Color(red: 0.07, green: 0.08, blue: 0.10)
        case .dark: return Color(red: 0.09, green: 0.15, blue: 0.12)
        case .amoled: return .black
        }
    }

    static func ink(_ theme: ThemeMode, ink: HandInkColor) -> Color {
        if theme.isDark { return Color(red: 0.92, green: 0.92, blue: 0.88) }
        switch ink {
        case .blue: return Color(red: 0.12, green: 0.20, blue: 0.42)
        case .black: return Color(red: 0.12, green: 0.12, blue: 0.13)
        case .pencil: return Color(red: 0.38, green: 0.39, blue: 0.40)
        }
    }

    static func text(_ theme: ThemeMode) -> Color {
        theme.isDark ? Color(red: 0.93, green: 0.93, blue: 0.89) : Color(red: 0.16, green: 0.15, blue: 0.13)
    }

    static func secondaryText(_ theme: ThemeMode) -> Color {
        theme.isDark ? Color(red: 0.65, green: 0.67, blue: 0.64) : Color(red: 0.44, green: 0.42, blue: 0.38)
    }

    static func accent(_ accent: Accent) -> Color {
        switch accent {
        case .lime: return Color(red: 0.55, green: 0.72, blue: 0.22)
        case .blue: return Color(red: 0.22, green: 0.52, blue: 0.82)
        case .orange: return Color(red: 0.92, green: 0.53, blue: 0.18)
        case .pink: return Color(red: 0.88, green: 0.40, blue: 0.55)
        case .purple: return Color(red: 0.55, green: 0.42, blue: 0.78)
        }
    }

    static func groupColor(_ group: String) -> Color {
        switch group {
        case "Грудь": return Color(red: 0.82, green: 0.38, blue: 0.36)
        case "Руки": return Color(red: 0.90, green: 0.60, blue: 0.25)
        case "Спина": return Color(red: 0.35, green: 0.55, blue: 0.75)
        case "Ноги": return Color(red: 0.45, green: 0.65, blue: 0.40)
        case "Плечи": return Color(red: 0.65, green: 0.45, blue: 0.75)
        case "Корпус": return Color(red: 0.85, green: 0.68, blue: 0.25)
        case "Фулбоди": return Color(red: 0.30, green: 0.65, blue: 0.62)
        case "Кардио": return Color(red: 0.80, green: 0.35, blue: 0.55)
        default: return Color(red: 0.55, green: 0.55, blue: 0.55)
        }
    }

    static func fontName(_ theme: ThemeMode) -> String? {
        switch theme {
        case .handwritten, .handwrittenDark: return "Caveat"
        default: return "Neucha"
        }
    }

    static func registerFonts() {
        for name in ["Neucha", "Caveat"] {
            guard let url = Bundle.main.url(forResource: name, withExtension: "ttf") else { continue }
            CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
        }
    }
}
