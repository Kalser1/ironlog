import Foundation

struct SharedExerciseMeta: Codable {
    var equipment: String = ""
    var level: String = ""
    var desc: String = ""
}

enum SharedPayload {
    case workout(Workout, [String: SharedExerciseMeta])
    case program(WorkoutProgram, [String: SharedExerciseMeta])
}

/// Полный порт формата LIFTBOOK1: (Base64 URL-safe от компактного JSON).
enum ShareCode {
    static let prefix = "LIFTBOOK1:"

    static func encodeWorkout(_ workout: Workout, catalog: [Exercise] = []) -> String {
        var root: [String: Any] = [
            "v": 1,
            "type": "workout",
            "startedAt": workout.startedAt,
            "finishedAt": workout.finishedAt
        ]
        let meta = customMeta(catalog)
        var exArray: [[String: Any]] = []
        for ex in workout.exercises {
            var eo: [String: Any] = [
                "name": ex.name,
                "group": ex.group,
                "note": ex.note
            ]
            if let m = meta[ex.name.trimmingCharacters(in: .whitespaces).lowercased()] {
                putMeta(&eo, m)
            }
            eo["sets"] = ex.sets.map { ["r": $0.reps] }  // веса наружу не едут
            exArray.append(eo)
        }
        root["exercises"] = exArray
        return prefix + encode(json(root))
    }

    static func encodeProgram(_ program: WorkoutProgram, catalog: [Exercise] = []) -> String {
        var root: [String: Any] = [
            "v": 1,
            "type": "program",
            "name": program.name,
            "comment": program.comment
        ]
        let meta = customMeta(catalog)
        var routines: [[String: Any]] = []
        for routine in program.routines {
            var ro: [String: Any] = ["name": routine.name, "comment": routine.comment]
            var exArray: [[String: Any]] = []
            for ex in routine.exercises {
                var eo: [String: Any] = [
                    "name": ex.name,
                    "group": ex.group,
                    "sets": ex.sets,
                    "reps": ex.reps,
                    "weight": "",
                    "comment": ex.comment
                ]
                if let ss = ex.supersetId { eo["superset"] = ss }
                if let m = meta[ex.name.trimmingCharacters(in: .whitespaces).lowercased()] {
                    putMeta(&eo, m)
                }
                exArray.append(eo)
            }
            ro["exercises"] = exArray
            routines.append(ro)
        }
        root["routines"] = routines
        return prefix + encode(json(root))
    }

    static func decode(_ raw: String) -> SharedPayload? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        var code: String? = nil
        if let range = text.range(of: #"(?:LIFTBOOK1|IRONLOG1):[A-Za-z0-9_=-]+"#, options: .regularExpression) {
            code = String(text[range])
        } else if text.hasPrefix("{") {
            code = text
        }
        guard let c = code else { return nil }
        let jsonString: String
        if c.hasPrefix("{") {
            jsonString = c
        } else {
            let part = c.split(separator: ":", maxSplits: 1).last.map(String.init) ?? ""
            guard let data = Data(base64Encoded: part, options: .ignoreUnknownCharacters),
                  let s = String(data: data, encoding: .utf8) else { return nil }
            jsonString = s
        }
        guard let data = jsonString.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data),
              let root = object as? [String: Any] else { return nil }
        let version = root["v"] as? Int ?? 0
        guard version <= 1 else { return nil }
        switch root["type"] as? String {
        case "workout": return parseWorkout(root)
        case "program": return parseProgram(root)
        default: return nil
        }
    }

    // MARK: - Приватное

    private static func json(_ object: [String: Any]) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: object, options: [.sortedKeys]),
              let s = String(data: data, encoding: .utf8) else { return "{}" }
        return s
    }

    private static func encode(_ json: String) -> String {
        json.data(using: .utf8)!.base64EncodedString(options: [])
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
    }

    private static func customMeta(_ catalog: [Exercise]) -> [String: SharedExerciseMeta] {
        var result: [String: SharedExerciseMeta] = [:]
        for ex in catalog where ex.custom {
            result[ex.name.trimmingCharacters(in: .whitespaces).lowercased()] = SharedExerciseMeta(
                equipment: String(ex.equipment.prefix(40)),
                level: String(ex.level.prefix(40)),
                desc: String(ex.desc.prefix(600))
            )
        }
        return result
    }

    private static func putMeta(_ target: inout [String: Any], _ meta: SharedExerciseMeta) {
        if !meta.equipment.trimmingCharacters(in: .whitespaces).isEmpty { target["eq"] = meta.equipment }
        if !meta.level.trimmingCharacters(in: .whitespaces).isEmpty { target["lvl"] = meta.level }
        if !meta.desc.trimmingCharacters(in: .whitespaces).isEmpty { target["d"] = meta.desc }
    }

    private static func readMeta(_ source: [String: Any]) -> SharedExerciseMeta? {
        let meta = SharedExerciseMeta(
            equipment: safe(source, "eq", 40),
            level: safe(source, "lvl", 40),
            desc: safe(source, "d", 600)
        )
        let has = !meta.equipment.isEmpty || !meta.level.isEmpty || !meta.desc.isEmpty
        return has ? meta : nil
    }

    private static func safe(_ o: [String: Any], _ key: String, _ max: Int) -> String {
        guard let raw = o[key] as? String else { return "" }
        return String(raw.trimmingCharacters(in: .whitespaces).prefix(max))
    }

    private static func parseWorkout(_ root: [String: Any]) -> SharedPayload? {
        guard let array = root["exercises"] as? [[String: Any]], !array.isEmpty else { return nil }
        var exercises: [LoggedExercise] = []
        var meta: [String: SharedExerciseMeta] = [:]
        for eo in array.prefix(200) {
            let name = safe(eo, "name", 120)
            guard !name.isEmpty else { continue }
            if let m = readMeta(eo) { meta[name.lowercased()] = m }
            var sets: [LoggedSet] = []
            if let setsArray = eo["sets"] as? [[String: Any]] {
                for so in setsArray.prefix(100) {
                    let reps = (so["r"] as? Int ?? 0).clamped(to: 0...1000)
                    sets.append(LoggedSet(weight: 0, reps: reps))
                }
            }
            exercises.append(LoggedExercise(
                name: name, group: safe(eo, "group", 40), sets: sets, note: safe(eo, "note", 500)
            ))
        }
        guard !exercises.isEmpty else { return nil }
        var startedAt = root["startedAt"] as? Int64 ?? (root["startedAt"] as? Int).map(Int64.init) ?? 0
        var finishedAt = root["finishedAt"] as? Int64 ?? (root["finishedAt"] as? Int).map(Int64.init) ?? 0
        if startedAt <= 0 || finishedAt <= 0 || finishedAt < startedAt {
            finishedAt = Periodization.nowMs()
            startedAt = finishedAt - 3600 * 1000
        }
        let workout = Workout(
            id: 0, startedAt: startedAt, finishedAt: finishedAt, exercises: exercises
        )
        return .workout(workout, meta)
    }

    private static func parseProgram(_ root: [String: Any]) -> SharedPayload? {
        let name = safe(root, "name", 120)
        guard !name.isEmpty else { return nil }
        let routinesArray = root["routines"] as? [[String: Any]] ?? []
        var routines: [Routine] = []
        var meta: [String: SharedExerciseMeta] = [:]
        for (i, ro) in routinesArray.prefix(50).enumerated() {
            let exArray = ro["exercises"] as? [[String: Any]] ?? []
            var exercises: [RoutineExercise] = []
            for eo in exArray.prefix(200) {
                let exerciseName = safe(eo, "name", 120)
                guard !exerciseName.isEmpty else { continue }
                if let m = readMeta(eo) { meta[exerciseName.lowercased()] = m }
                exercises.append(RoutineExercise(
                    name: exerciseName,
                    group: safe(eo, "group", 40),
                    sets: (eo["sets"] as? Int ?? 3).clamped(to: 1...20),
                    reps: (eo["reps"] as? Int ?? 10).clamped(to: 1...100),
                    weight: "0",
                    comment: safe(eo, "comment", 500),
                    supersetId: safe(eo, "superset", 80).isEmpty ? nil : safe(eo, "superset", 80)
                ))
            }
            routines.append(Routine(
                id: Int64(i + 1), name: safe(ro, "name", 120).isEmpty ? "Рутина \(i + 1)" : safe(ro, "name", 120),
                comment: safe(ro, "comment", 500), exercises: exercises
            ))
        }
        let program = WorkoutProgram(
            id: 0, name: name, createdAt: 0, comment: safe(root, "comment", 1000), routines: routines
        )
        return .program(program, meta)
    }
}
