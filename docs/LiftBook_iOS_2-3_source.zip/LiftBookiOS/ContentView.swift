import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: Store
    @ObservedObject private var reminders = ReminderManager.shared
    @State private var selection = 0
    @State private var showImport = false
    @State private var importText = ""
    @State private var importAlert: String? = nil

    var body: some View {
        TabView(selection: $selection) {
            NavigationStack {
                HomeView()
            }
            .tabItem { Label("Главная", systemImage: "house") }
            .tag(0)

            NavigationStack {
                CatalogView()
            }
            .tabItem { Label("Каталог", systemImage: "book") }
            .tag(1)

            NavigationStack {
                ProgramsView()
            }
            .tabItem { Label("Программы", systemImage: "square.stack.3d.up") }
            .tag(2)

            NavigationStack {
                HistoryView()
            }
            .tabItem { Label("История", systemImage: "clock.arrow.circlepath") }
            .tag(3)

            NavigationStack {
                MoreView()
            }
            .tabItem { Label("Ещё", systemImage: "ellipsis.circle") }
            .tag(4)
        }
        .accentColor(LiftTheme.accent(store.state.settings.accent))
        .onAppear {
            LiftTheme.registerFonts()
            reminders.refreshAuthorizationAndSync(reminders: store.state.reminders)
            UITabBar.appearance().barTintColor = UIColor(LiftTheme.paper(store.state.settings.theme))
        }
        .sheet(isPresented: $showImport) {
            NavigationStack {
                Form {
                    Section("Код LiftBook") {
                        TextEditor(text: $importText)
                            .frame(minHeight: 120)
                        Text("Вставь код LIFTBOOK1: из сообщения друга.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    Section {
                        Button("Импортировать") {
                            if let result = store.importShareCode(importText) {
                                switch result.payload {
                                case .workout:
                                    importAlert = "Тренировка импортирована\(notice(result.addedToCustom))"
                                case .program(let p, _):
                                    importAlert = "Программа «\(p.name)» импортирована\(notice(result.addedToCustom))"
                                }
                                importText = ""
                                showImport = false
                            } else {
                                importAlert = "Не удалось распознать код"
                            }
                        }
                        .disabled(importText.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                }
                .navigationTitle("Импорт")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Отмена") { showImport = false }
                    }
                }
            }
        }
        .alert(item: Binding(
            get: { importAlert.map { AlertMessage(message: $0) } },
            set: { _ in importAlert = nil }
        )) { alert in
            Alert(title: Text("LiftBook"), message: Text(alert.message))
        }
        .onOpenURL { url in
            if url.host == "import", let code = url.queryParameters?["code"] {
                importText = code
                showImport = true
            }
        }
    }

    private func notice(_ count: Int) -> String {
        count > 0 ? " · в «Своё» добавлено: \(count)" : ""
    }
}

struct AlertMessage: Identifiable {
    let id = UUID()
    let message: String
}

extension URL {
    var queryParameters: [String: String]? {
        guard let components = URLComponents(url: self, resolvingAgainstBaseURL: false),
              let items = components.queryItems else { return nil }
        return Dictionary(uniqueKeysWithValues: items.compactMap { item in
            guard let value = item.value else { return nil }
            return (item.name, value)
        })
    }
}
