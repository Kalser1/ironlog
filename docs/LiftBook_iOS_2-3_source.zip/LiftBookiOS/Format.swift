import Foundation

func formatWeight(_ value: Double) -> String {
    if value == floor(value) { return String(format: "%.0f", value) }
    return String(format: "%.1f", locale: Locale(identifier: "en_US_POSIX"), value)
}

func formatRoutineWeight(_ raw: String) -> String {
    let trimmed = raw.trimmingCharacters(in: .whitespaces)
        .trimmingCharacters(in: CharacterSet(charactersIn: ",."))
    if trimmed.isEmpty { return "" }
    let normalized = trimmed.replacingOccurrences(of: ",", with: ".")
    if let value = Double(normalized), value == 0 { return "" }
    return trimmed
}

func formatVolume(_ value: Double) -> String {
    let formatter = NumberFormatter()
    formatter.numberStyle = .decimal
    formatter.groupingSeparator = " "
    formatter.maximumFractionDigits = 0
    let s = formatter.string(from: NSNumber(value: Int64(value))) ?? "\(Int64(value))"
    return "\(s) кг"
}

func formatDuration(_ ms: Int64) -> String {
    let totalMinutes = ms / 60000
    let hours = totalMinutes / 60
    let minutes = totalMinutes % 60
    if hours > 0 { return "\(hours) ч \(minutes) мин" }
    if minutes > 0 { return "\(minutes) мин" }
    return "< 1 мин"
}

func formatTimer(_ ms: Int64) -> String {
    let total = max(0, ms / 1000)
    let hours = total / 3600
    let minutes = (total % 3600) / 60
    let seconds = total % 60
    if hours > 0 { return String(format: "%d:%02d:%02d", hours, minutes, seconds) }
    return String(format: "%02d:%02d", minutes, seconds)
}

func formatDate(_ timestamp: Int64) -> String {
    let d = Date(timeIntervalSince1970: Double(timestamp) / 1000)
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "d MMM yyyy, HH:mm"
    return f.string(from: d)
}

func formatShortDate(_ timestamp: Int64) -> String {
    let d = Date(timeIntervalSince1970: Double(timestamp) / 1000)
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "d MMM"
    return f.string(from: d)
}

func formatLongDate(_ timestamp: Int64) -> String {
    let d = Date(timeIntervalSince1970: Double(timestamp) / 1000)
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "EEEE, d MMMM"
    return f.string(from: d).capitalized
}

private func plural(_ count: Int, _ one: String, _ few: String, _ many: String) -> String {
    let mod100 = count % 100
    let mod10 = count % 10
    let word: String
    if (11...14).contains(mod100) { word = many }
    else if mod10 == 1 { word = one }
    else if (2...4).contains(mod10) { word = few }
    else { word = many }
    return "\(count) \(word)"
}

func pluralExercises(_ n: Int) -> String { plural(n, "упражнение", "упражнения", "упражнений") }
func pluralRoutines(_ n: Int) -> String { plural(n, "рутина", "рутины", "рутин") }
func pluralPrograms(_ n: Int) -> String { plural(n, "программа", "программы", "программ") }
func pluralWorkouts(_ n: Int) -> String { plural(n, "тренировка", "тренировки", "тренировок") }
func pluralSets(_ n: Int) -> String { plural(n, "подход", "подхода", "подходов") }
func pluralReps(_ n: Int) -> String { plural(n, "повторение", "повторения", "повторений") }
