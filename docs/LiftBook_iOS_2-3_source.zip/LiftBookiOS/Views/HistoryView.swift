import SwiftUI

struct HistoryView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: "История", subtitle: pluralWorkouts(store.state.history.count))
                if store.state.history.isEmpty {
                    EmptyState(title: "Пока пусто", message: "Заверши первую тренировку — она появится здесь.")
                } else {
                    LazyVStack(spacing: 10) {
                        ForEach(store.state.history) { workout in
                            NavigationLink(value: Route.historyDetail(workout.id)) {
                                PaperCard {
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(formatDate(workout.finishedAt))
                                            .fontWeight(.semibold)
                                            .foregroundColor(LiftTheme.text(store.state.settings.theme))
                                        Text("\(pluralExercises(workout.exercises.count)) · \(pluralSets(workout.totalSets)) · \(formatVolume(workout.volume))")
                                            .font(.caption)
                                            .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                                        if let phaseId = workout.phase {
                                            Text("Фаза: \(phaseName(phaseId))")
                                                .font(.caption2)
                                                .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                                        }
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .navigationDestination(for: Route.self) { $0.destination }
    }

    private func phaseName(_ id: String) -> String {
        Periodization.defaultPhases.first { $0.id == id }?.name ?? id
    }
}

struct HistoryDetailView: View {
    @EnvironmentObject var store: Store
    let workoutId: Int64
    @Environment(\.dismiss) var dismiss

    private var workout: Workout? { store.state.history.first { $0.id == workoutId } }

    var body: some View {
        Group {
            if let workout {
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        ScreenHeader(title: formatDate(workout.finishedAt), subtitle: formatDuration(workout.durationMs))
                        HStack(spacing: 12) {
                            stat("Объём", formatVolume(workout.volume))
                            stat("Подходы", "\(workout.totalSets)")
                            stat("Время", formatDuration(workout.durationMs))
                        }
                        ForEach(Array(workout.exercises.indices), id: \.self) { i in
                            let ex = workout.exercises[i]
                            PaperCard {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(ex.name).fontWeight(.semibold)
                                    Text(ex.sets.map { s in
                                        s.weight > 0 ? "\(formatWeight(s.weight)) кг × \(s.reps)" : "\(s.reps) повт."
                                    }.joined(separator: " · "))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                        if let code = shareCode(for: workout) {
                            ShareLink(item: code) { Label("Поделиться", systemImage: "square.and.arrow.up") }
                            .buttonStyle(.bordered)
                        }
                        Button("Удалить тренировку", role: .destructive) {
                            store.state.history.removeAll { $0.id == workoutId }
                            store.save()
                            dismiss()
                        }
                    }
                    .padding()
                }
            } else {
                EmptyState(title: "Не найдено", message: "Тренировка отсутствует в истории.")
            }
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
    }

    private func stat(_ title: String, _ value: String) -> some View {
        PaperCard {
            VStack(spacing: 4) {
                Text(title).font(.caption).foregroundColor(.secondary)
                Text(value).font(.headline)
            }
            .frame(maxWidth: .infinity)
        }
    }

    private func shareCode(for workout: Workout) -> String {
        store.state.settings.shareCodeOnly
            ? ShareCode.encodeWorkout(workout, catalog: store.exercises)
            : workout.exercises.map { ex in
                "\(ex.name): " + ex.sets.map { "\($0.reps) повт." }.joined(separator: ", ")
            }.joined(separator: "\n")
    }
}
