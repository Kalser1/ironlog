import SwiftUI

struct CatalogView: View {
    @EnvironmentObject var store: Store
    @State private var search = ""
    @State private var group: String? = nil
    @State private var showCustomEditor = false

    private var filtered: [Exercise] {
        var items = store.exercises
        if let group {
            if group == ExerciseCatalog.customGroup {
                items = items.filter { $0.custom }
            } else {
                items = items.filter { $0.group == group }
            }
        }
        if !search.isEmpty {
            items = items.filter { $0.name.localizedCaseInsensitiveContains(search) }
        }
        return items
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: group ?? "Каталог", subtitle: subtitle)

                HStack {
                    TextField("Поиск упражнений", text: $search)
                        .textFieldStyle(.roundedBorder)
                    Button {
                        showCustomEditor = true
                    } label: {
                        Image(systemName: "plus")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(LiftTheme.accent(store.state.settings.accent))
                }

                if group == nil {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(store.groups, id: \.self) { g in
                                Button {
                                    self.group = g
                                } label: {
                                    HStack(spacing: 4) {
                                        Circle().fill(LiftTheme.groupColor(g)).frame(width: 8, height: 8)
                                        Text(g)
                                    }
                                    .padding(.horizontal, 10).padding(.vertical, 6)
                                    .background(Color.secondary.opacity(0.1))
                                    .cornerRadius(16)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }

                LazyVStack(spacing: 8) {
                    ForEach(filtered) { ex in
                        NavigationLink(value: Route.exerciseDetail(ex.name)) {
                            PaperCard {
                                HStack {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(ex.name)
                                            .foregroundColor(LiftTheme.text(store.state.settings.theme))
                                        HStack {
                                            GroupBadge(group: ex.group)
                                            Text(ex.equipment)
                                                .font(.caption)
                                                .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                                        }
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .navigationDestination(for: Route.self) { $0.destination }
        .sheet(isPresented: $showCustomEditor) {
            CustomExerciseEditor { exercise in
                _ = store.addCustomExercise(exercise)
                showCustomEditor = false
            }
        }
    }

    private var subtitle: String {
        if let group {
            return group == ExerciseCatalog.customGroup
                ? "Твои упражнения · \(store.state.customExercises.count)"
                : pluralExercises(filtered.count)
        }
        return "\(pluralExercises(store.exercises.count)) · \(store.groups.count) групп"
    }
}

struct ExerciseDetailView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let name: String
    @State private var showEditor = false

    private var exercise: Exercise? { store.exercise(named: name) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if let ex = exercise {
                    ScreenHeader(title: ex.name, subtitle: ex.group)
                    PaperCard {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack { Text("Оборудование"); Spacer(); Text(ex.equipment).foregroundColor(.secondary) }
                            HStack { Text("Уровень"); Spacer(); Text(ex.level).foregroundColor(.secondary) }
                            Text(ex.desc)
                                .font(.subheadline)
                                .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                        }
                    }
                    if ex.custom {
                        Button("Редактировать упражнение") { showEditor = true }
                        Button("Удалить упражнение", role: .destructive) {
                            store.deleteCustomExercise(ex.id)
                            dismiss()
                        }
                    }
                    Button("Добавить в тренировку") {
                        if store.state.active == nil { store.startWorkout() }
                        var active = store.state.active!
                        active.exercises.append(ActiveExercise(
                            name: ex.name, group: ex.group,
                            sets: [ActiveSet(weight: store.lastWeight(for: ex.name) ?? "", reps: "10")]
                        ))
                        store.state.active = active
                        store.save()
                        dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(LiftTheme.accent(store.state.settings.accent))

                    // Прогресс по весу
                    let points = progressPoints(history: store.state.history, name: ex.name)
                    if !points.isEmpty {
                        PaperCard {
                            VStack(alignment: .leading) {
                                Text("Прогресс").font(.headline)
                                Text("\(points.count) \(points.count == 1 ? "запись" : "записей") с весом")
                                    .font(.caption).foregroundColor(.secondary)
                            }
                        }
                    }
                } else {
                    EmptyState(title: "Не найдено", message: "Упражнение отсутствует в каталоге.")
                }
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .sheet(isPresented: $showEditor) {
            if let ex = exercise {
                CustomExerciseEditor(exercise: ex) { updated in
                    _ = store.updateCustomExercise(updated)
                    showEditor = false
                }
            }
        }
    }
}

func progressPoints(history: [Workout], name: String) -> [(date: Int64, weight: Double)] {
    history.sorted { $0.finishedAt < $1.finishedAt }.compactMap { workout in
        guard let ex = workout.exercises.first(where: { $0.name == name }),
              let w = ex.bestWeight > 0 ? ex.bestWeight : nil else { return nil }
        return (workout.finishedAt, w)
    }
}

struct CustomExerciseEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    var exercise: Exercise? = nil
    let onSave: (Exercise) -> Void

    @State private var name = ""
    @State private var group = "Грудь"
    @State private var equipment = ""
    @State private var level = "Средний"
    @State private var desc = ""
    @State private var error: String? = nil

    private var groupsWithoutCustom: [String] {
        ExerciseCatalog.groupOrder.filter { $0 != ExerciseCatalog.customGroup }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Упражнение") {
                    TextField("Название", text: $name)
                    Picker("Группа мышц", selection: $group) {
                        ForEach(groupsWithoutCustom, id: \.self) { Text($0).tag($0) }
                    }
                    TextField("Оборудование", text: $equipment)
                    Picker("Уровень", selection: $level) {
                        ForEach(["Начальный", "Средний", "Продвинутый"], id: \.self) { Text($0).tag($0) }
                    }
                    TextField("Описание техники", text: $desc, axis: .vertical)
                }
                if let error {
                    Section { Text(error).foregroundColor(.red) }
                }
            }
            .navigationTitle(exercise == nil ? "Новое упражнение" : "Редактирование")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        let trimmed = name.trimmingCharacters(in: .whitespaces)
                        guard !trimmed.isEmpty else { error = "Введите название"; return }
                        if let existing = exercise {
                            var updated = existing
                            updated.name = trimmed
                            updated.group = group
                            updated.equipment = equipment
                            updated.level = level
                            updated.desc = desc
                            onSave(updated)
                        } else {
                            onSave(Exercise(
                                name: trimmed, group: group, equipment: equipment,
                                level: level, desc: desc, custom: true
                            ))
                        }
                    }
                }
            }
        }
        .onAppear {
            if let ex = exercise {
                name = ex.name; group = ex.group; equipment = ex.equipment
                level = ex.level; desc = ex.desc
            }
        }
    }
}
