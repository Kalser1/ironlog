import SwiftUI

struct ProgramsView: View {
    @EnvironmentObject var store: Store
    @State private var showNew = false
    @State private var newName = ""
    @State private var showImport = false
    @State private var importText = ""
    @State private var importError: String? = nil

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: "Программы", subtitle: pluralPrograms(store.state.programs.count))
                HStack {
                    Button("Создать программу") { showNew = true }
                        .buttonStyle(.borderedProminent)
                        .tint(LiftTheme.accent(store.state.settings.accent))
                    Button("Импорт") { showImport = true }
                        .buttonStyle(.bordered)
                }
                if store.state.programs.isEmpty {
                    EmptyState(title: "Пока нет программ", message: "Собери свою программу из упражнений или импортируй код друга.")
                } else {
                    LazyVStack(spacing: 10) {
                        ForEach(store.state.programs) { program in
                            NavigationLink(value: Route.programDetail(program.id)) {
                                PaperCard {
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(program.name)
                                            .fontWeight(.semibold)
                                            .foregroundColor(LiftTheme.text(store.state.settings.theme))
                                        Text(program.comment.isEmpty ? "Без комментария" : program.comment)
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                        Text("\(pluralRoutines(program.routines.count)) · \(pluralExercises(program.exerciseCount)) · \(pluralSets(program.totalSets))")
                                            .font(.caption)
                                            .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .navigationDestination(for: Route.self) { $0.destination }
        .sheet(isPresented: $showNew) {
            AlertEditor(title: "Новая программа", text: $newName) {
                let trimmed = newName.trimmingCharacters(in: .whitespaces)
                guard !trimmed.isEmpty else { return }
                _ = store.createProgram(name: trimmed)
                newName = ""
                showNew = false
            }
        }
        .sheet(isPresented: $showImport) {
            AlertEditor(title: "Импорт программы", text: $importText, multiLine: true, confirmTitle: "Импортировать") {
                if store.importShareCode(importText) != nil {
                    importText = ""
                    showImport = false
                } else {
                    importError = "Код не распознан"
                }
            }
        }
        .alert("Ошибка", isPresented: Binding(get: { importError != nil }, set: { if !$0 { importError = nil } })) {
            Button("Ок", role: .cancel) {}
        } message: {
            Text(importError ?? "")
        }
    }
}

struct AlertEditor: View {
    @Environment(\.dismiss) var dismiss
    let title: String
    @Binding var text: String
    var multiLine: Bool = false
    var confirmTitle: String = "Создать"
    let confirm: () -> Void

    var body: some View {
        NavigationStack {
            Form {
                if multiLine {
                    TextEditor(text: $text).frame(minHeight: 140)
                } else {
                    TextField("Название", text: $text)
                }
            }
            .navigationTitle(title)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(confirmTitle) { confirm(); dismiss() }
                }
            }
        }
    }
}

struct ProgramDetailView: View {
    @EnvironmentObject var store: Store
    let programId: Int64
    @State private var showCycleEditor = false
    @State private var showRoutineEditor = false
    @State private var editingRoutineId: Int64? = nil
    @State private var showNewRoutine = false
    @State private var routineName = ""
    @State private var confirmStartRoutine: Int64? = nil

    private var program: WorkoutProgram? {
        store.state.programs.first { $0.id == programId }
    }

    var body: some View {
        Group {
            if let program {
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        ScreenHeader(title: program.name, subtitle: program.comment.isEmpty ? nil : program.comment)

                        PaperCard {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("ПЕРИОДИЗАЦИЯ")
                                    .font(.caption.weight(.bold))
                                    .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                                if program.cycleEnabled, program.cycleStartAt > 0 {
                                    let week = Periodization.weekIndex(cycleStartAt: program.cycleStartAt, phases: program.cyclePhases)
                                    let phase = Periodization.phaseForWeek(week, phases: program.cyclePhases)
                                    Text("Неделя \(week + 1) из \(Periodization.totalWeeks(program.cyclePhases)) · \(phase.name)")
                                        .fontWeight(.semibold)
                                        .foregroundColor(LiftTheme.text(store.state.settings.theme))
                                    Text("Сейчас: \(Periodization.adjustmentLabel(phase))")
                                        .font(.caption).foregroundColor(.secondary)
                                    let days = Periodization.daysLeftInPhase(cycleStartAt: program.cycleStartAt, phases: program.cyclePhases)
                                    Text("До смены фазы: \(days) дн. · старт \(formatDate(program.cycleStartAt))")
                                        .font(.caption).foregroundColor(.secondary)
                                } else {
                                    Text("Цикл выключен")
                                        .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                                }
                                HStack {
                                    Button(program.cycleEnabled ? "Выключить" : "Включить") {
                                        store.setProgramCycle(programId, enabled: !program.cycleEnabled)
                                    }
                                    .buttonStyle(.bordered)
                                    Button("Настроить цикл") { showCycleEditor = true }
                                        .buttonStyle(.bordered)
                                }
                                Button("Начать цикл заново") {
                                    store.restartProgramCycle(programId)
                                }
                                .buttonStyle(.borderless)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }

                        Text("Рутины")
                            .font(.custom(LiftTheme.fontName(store.state.settings.theme) ?? "System", size: 22))
                            .foregroundColor(LiftTheme.text(store.state.settings.theme))

                        ForEach(program.routines) { routine in
                            PaperCard {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(routine.name).fontWeight(.semibold)
                                    Text(routine.comment.isEmpty ? "Без комментария" : routine.comment)
                                        .font(.caption).foregroundColor(.secondary)
                                    Text("\(pluralExercises(routine.exercises.count)) · \(pluralSets(routine.totalSets))")
                                        .font(.caption).foregroundColor(.secondary)
                                    HStack {
                                        Button("Начать") { confirmStartRoutine = routine.id }
                                            .buttonStyle(.borderedProminent)
                                            .tint(LiftTheme.accent(store.state.settings.accent))
                                        Button("Изменить") {
                                            editingRoutineId = routine.id
                                            showRoutineEditor = true
                                        }
                                        .buttonStyle(.bordered)
                                        Spacer()
                                        Button(role: .destructive) {
                                            var copy = program
                                            copy.routines.removeAll { $0.id == routine.id }
                                            updateProgram(copy)
                                        } label: { Image(systemName: "trash") }
                                        .buttonStyle(.borderless)
                                    }
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }

                        Button("Добавить рутину") { showNewRoutine = true }
                            .buttonStyle(.bordered)

                        if let code = shareCode(for: program) {
                            ShareLink(item: code) {
                                Label("Поделиться программой", systemImage: "square.and.arrow.up")
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    .padding()
                }
            } else {
                EmptyState(title: "Программа не найдена", message: "Возможно, она была удалена.")
            }
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .sheet(isPresented: $showCycleEditor) {
            CycleEditorView(programId: programId)
        }
        .sheet(isPresented: $showRoutineEditor) {
            if let id = editingRoutineId {
                RoutineEditorView(programId: programId, routineId: id)
            }
        }
        .sheet(isPresented: $showNewRoutine) {
            AlertEditor(title: "Новая рутина", text: $routineName) {
                let trimmed = routineName.trimmingCharacters(in: .whitespaces)
                guard !trimmed.isEmpty, var copy = program else { return }
                copy.routines.append(Routine(id: Periodization.nowMs(), name: trimmed))
                updateProgram(copy)
                routineName = ""
                showNewRoutine = false
            }
        }
        .confirmationDialog("Начать рутину?", isPresented: Binding(
            get: { confirmStartRoutine != nil }, set: { if !$0 { confirmStartRoutine = nil } }
        )) {
            Button("Начать") {
                if let rid = confirmStartRoutine {
                    store.startWorkoutFromRoutine(programId: programId, routineId: rid)
                }
            }
            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Текущая активная тренировка будет заменена новой.")
        }
    }

    private func updateProgram(_ program: WorkoutProgram) {
        guard let idx = store.state.programs.firstIndex(where: { $0.id == programId }) else { return }
        store.state.programs[idx] = program
        store.save()
    }

    private func shareCode(for program: WorkoutProgram) -> String? {
        store.state.settings.shareCodeOnly
            ? ShareCode.encodeProgram(program, catalog: store.exercises)
            : "LiftBook — программа «\(program.name)»\n\(program.routines.map { $0.name }.joined(separator: ", "))"
    }
}

// MARK: - Редактор цикла

struct CycleEditorView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let programId: Int64
    @State private var phases: [CyclePhaseConfig] = []

    private var program: WorkoutProgram? { store.state.programs.first { $0.id == programId } }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Фазы идут по очереди и повторяются по кругу. Длительность — в неделях. Процент меняет вес относительно базового, сдвиги — повторы и подходы. Изменения применяются сразу; чтобы начать с первой фазы, нажми «Начать цикл заново».")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                ForEach(phases.indices, id: \.self) { index in
                    Section("ФАЗА \(index + 1)") {
                        TextField("Название фазы", text: Binding(
                            get: { phases[index].name },
                            set: { phases[index].name = String($0.prefix(24)) }
                        ))
                        StepperRow(title: "Длительность", value: "\(phases[index].weeks) нед.",
                                   decrease: { phases[index].weeks = max(1, phases[index].weeks - 1) },
                                   increase: { phases[index].weeks = min(12, phases[index].weeks + 1) })
                        StepperRow(title: "Вес", value: percentLabel(phases[index].weightFactor),
                                   decrease: { phases[index].weightFactor = max(0.5, phases[index].weightFactor - 0.05) },
                                   increase: { phases[index].weightFactor = min(2.0, phases[index].weightFactor + 0.05) })
                        StepperRow(title: "Повторы", value: deltaLabel(phases[index].repsDelta),
                                   decrease: { phases[index].repsDelta = max(-20, phases[index].repsDelta - 1) },
                                   increase: { phases[index].repsDelta = min(20, phases[index].repsDelta + 1) })
                        StepperRow(title: "Подходы", value: deltaLabel(phases[index].setsDelta),
                                   decrease: { phases[index].setsDelta = max(-10, phases[index].setsDelta - 1) },
                                   increase: { phases[index].setsDelta = min(10, phases[index].setsDelta + 1) })
                        HStack {
                            Button("Выше") { moveUp(index) }.disabled(index == 0)
                            Button("Ниже") { moveDown(index) }.disabled(index == phases.count - 1)
                            Spacer()
                            Button("Удалить", role: .destructive) { phases.remove(at: index) }
                        }
                        .buttonStyle(.borderless)
                    }
                }
                Section {
                    Button("Добавить фазу") {
                        phases.append(CyclePhaseConfig(
                            id: "phase-\(Periodization.nowMs())", name: "Фаза \(phases.count + 1)",
                            weeks: 1, weightFactor: 1.0, repsDelta: 0, setsDelta: 0
                        ))
                    }
                }
                Section {
                    Text("Всего: \(Periodization.totalWeeks(phases)) нед. · \(phases.map(\.name).joined(separator: " → "))")
                        .font(.caption)
                }
            }
            .navigationTitle("Настройка цикла")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        store.saveProgramCyclePhases(programId, phases: phases)
                        dismiss()
                    }
                }
                ToolbarItem(placement: .bottomBar) {
                    Button("Сбросить") { phases = Periodization.defaultPhases }
                }
            }
        }
        .onAppear {
            phases = program?.cyclePhases ?? Periodization.defaultPhases
        }
    }

    private func percentLabel(_ factor: Double) -> String {
        let p = Int((factor - 1.0) * 100)
        return p == 0 ? "базовый" : (p > 0 ? "+\(p)%" : "−\(-p)%")
    }

    private func deltaLabel(_ v: Int) -> String { v == 0 ? "без изм." : Periodization.signed(v) }
    private func moveUp(_ i: Int) { if i > 0 { phases.swapAt(i, i - 1) } }
    private func moveDown(_ i: Int) { if i < phases.count - 1 { phases.swapAt(i, i + 1) } }
}

// MARK: - Редактор рутины

struct RoutineEditorView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let programId: Int64
    let routineId: Int64

    private var routine: Routine? {
        store.state.programs.first { $0.id == programId }?.routines.first { $0.id == routineId }
    }

    @State private var showExercisePicker = false
    @State private var name = ""
    @State private var comment = ""

    var body: some View {
        Group {
            if let routine {
                Form {
                    Section("Рутина") {
                        TextField("Название", text: Binding(
                            get: { name },
                            set: { v in name = v; mutate { $0.name = v } }
                        ))
                        TextField("Комментарий", text: Binding(
                            get: { comment },
                            set: { v in comment = v; mutate { $0.comment = v } }
                        ))
                    }
                    Section("Упражнения") {
                        ForEach(routine.exercises.indices, id: \.self) { i in
                            VStack(alignment: .leading, spacing: 6) {
                                TextField("Название", text: Binding(
                                    get: { routine.exercises[i].name },
                                    set: { v in mutate { $0.exercises[i].name = v } }
                                ))
                                HStack {
                                    TextField("Подх.", text: Binding(
                                        get: { String(routine.exercises[i].sets) },
                                        set: { v in mutate { $0.exercises[i].sets = Int(v) ?? 3 } }
                                    )).keyboardType(.numberPad).frame(width: 60)
                                    TextField("Повт.", text: Binding(
                                        get: { String(routine.exercises[i].reps) },
                                        set: { v in mutate { $0.exercises[i].reps = Int(v) ?? 10 } }
                                    )).keyboardType(.numberPad).frame(width: 60)
                                    TextField("Вес", text: Binding(
                                        get: { routine.exercises[i].weight },
                                        set: { v in mutate { $0.exercises[i].weight = v } }
                                    )).keyboardType(.decimalPad)
                                }
                                Button("Удалить", role: .destructive) {
                                    mutate { $0.exercises.remove(at: i) }
                                }
                            }
                        }
                        Button("Добавить упражнение") { showExercisePicker = true }
                    }
                    Section {
                        Button("Начать рутину") {
                            store.startWorkoutFromRoutine(programId: programId, routineId: routineId)
                            dismiss()
                        }
                    }
                }
                .navigationTitle("Редактор рутины")
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
                }
                .sheet(isPresented: $showExercisePicker) {
                    NavigationStack {
                        List(store.exercises) { ex in
                            Button(ex.name) {
                                mutate { r in
                                    r.exercises.append(RoutineExercise(
                                        name: ex.name, group: ex.group, sets: 3, reps: 10, weight: ""
                                    ))
                                }
                                showExercisePicker = false
                            }
                        }
                        .navigationTitle("Добавить упражнение")
                    }
                }
                .onAppear {
                    name = routine.name
                    comment = routine.comment
                }
            }
        }
    }

    /// Безопасное изменение рутины через хранилище.
    private func mutate(_ block: (inout Routine) -> Void) {
        guard let pi = store.state.programs.firstIndex(where: { $0.id == programId }),
              let ri = store.state.programs[pi].routines.firstIndex(where: { $0.id == routineId }) else { return }
        block(&store.state.programs[pi].routines[ri])
        store.save()
    }
}
