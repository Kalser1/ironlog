import SwiftUI

struct PaperCard<Content: View>: View {
    @EnvironmentObject var store: Store
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 14)
                    .fill(LiftTheme.paper(store.state.settings.theme).opacity(0.6))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(LiftTheme.ink(store.state.settings.theme, ink: store.state.settings.inkColor).opacity(0.25), lineWidth: 1)
            )
    }
}

struct ScreenHeader: View {
    @EnvironmentObject var store: Store
    let title: String
    var subtitle: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.custom(LiftTheme.fontName(store.state.settings.theme) ?? "System", size: 32))
                .foregroundColor(LiftTheme.text(store.state.settings.theme))
            if let subtitle {
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.bottom, 4)
    }
}

struct GroupBadge: View {
    let group: String
    var body: some View {
        Text(group)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(LiftTheme.groupColor(group).opacity(0.18))
            .foregroundColor(LiftTheme.groupColor(group))
            .cornerRadius(8)
    }
}

struct EmptyState: View {
    @EnvironmentObject var store: Store
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: 10) {
            Text(title)
                .font(.custom(LiftTheme.fontName(store.state.settings.theme) ?? "System", size: 22))
                .foregroundColor(LiftTheme.text(store.state.settings.theme))
            Text(message)
                .font(.subheadline)
                .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 40)
    }
}

struct StepperRow: View {
    @EnvironmentObject var store: Store
    let title: String
    let value: String
    let decrease: () -> Void
    let increase: () -> Void

    var body: some View {
        HStack {
            Text(title).foregroundColor(LiftTheme.text(store.state.settings.theme))
            Spacer()
            Button(action: decrease) {
                Image(systemName: "minus.circle")
            }
            Text(value)
                .frame(minWidth: 52)
                .multilineTextAlignment(.center)
                .foregroundColor(LiftTheme.text(store.state.settings.theme))
            Button(action: increase) {
                Image(systemName: "plus.circle")
            }
        }
        .buttonStyle(.borderless)
        .tint(LiftTheme.accent(store.state.settings.accent))
    }
}

struct AccentButton: View {
    @EnvironmentObject var store: Store
    let title: String
    let action: () -> Void
    var disabled: Bool = false

    var body: some View {
        Button(action: action) {
            Text(title)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(disabled ? Color.gray.opacity(0.3) : LiftTheme.accent(store.state.settings.accent))
                .foregroundColor(.white)
                .cornerRadius(12)
        }
        .disabled(disabled)
    }
}
