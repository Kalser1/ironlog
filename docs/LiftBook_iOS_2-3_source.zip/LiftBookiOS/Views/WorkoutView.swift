import SwiftUI

struct WorkoutView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State private var showFinishConfirm = false
    @State private var elapsed: Int64 = 0
    @State private var restLeft: Int = 0
    @State private var restTotal: Int = 0
    @State private var restNext: String? = nil

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        Group {
            if store.state.active != nil {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        ScreenHeader(
                            title: "Тренировка",
                            subtitle: store.state.active?.routineName ?? formatTimer(elapsed * 1000)
                        )

                        if let info = store.currentPhaseInfo() {
                            PaperCard {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("НЕДЕЛЯ \(info.week) ИЗ \(info.total)")
                                        .font(.caption.weight(.bold))
                                        .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                                    Text("\(info.phase.name) фаза")
                                        .font(.headline)
                                        .foregroundColor(LiftTheme.text(store.state.settings.theme))
                                    Text(Periodization.adjustmentLabel(info.phase))
                                        .font(.caption)
                                        .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                                    Text("До смены фазы: \(info.daysLeft) дн.")
                                        .font(.caption)
                                        .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }

                        if restLeft > 0 {
                            PaperCard {
                                VStack(spacing: 8) {
                                    Text("Отдых \(formatTimer(Int64(restLeft) * 1000))")
                                        .font(.title2.weight(.semibold))
                                        .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                                    if let next = restNext {
                                        Text("Дальше: \(next)").font(.caption).foregroundColor(.secondary)
                                    }
                                    ProgressView(value: Double(restTotal - restLeft), total: Double(max(1, restTotal)))
                                    HStack {
                                        Button("−15 с") { restLeft = max(0, restLeft - 15) }
                                        Button("+15 с") { restLeft += 15 }
                                        Button("Стоп") { cancelRest() }
                                    }
                                    .buttonStyle(.borderless)
                                }
                            }
                        }

                        ForEach(Array((store.state.active?.exercises.indices ?? Range(0..<0))), id: \.self) { index in
                            exerciseCard(index: index)
                        }

                        HStack {
                            NavigationLink("Добавить упражнение") { CatalogPickView() }
                                .buttonStyle(.bordered)
                            Spacer()
                            Button("Завершить", role: .destructive) { showFinishConfirm = true }
                                .buttonStyle(.borderedProminent)
                                .tint(LiftTheme.accent(store.state.settings.accent))
                        }
                    }
                    .padding()
                }
            } else {
                EmptyState(title: "Нет активной тренировки", message: "Нажми «Начать тренировку» на главной.")
            }
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .onReceive(timer) { _ in
            guard let started = store.state.active?.startedAt else { return }
            elapsed = (Periodization.nowMs() - started) / 1000
            if restLeft > 0 { restLeft -= 1 }
        }
        .confirmationDialog("Завершить тренировку?", isPresented: $showFinishConfirm) {
            Button("Завершить", role: .destructive) {
                if store.finishWorkout() { dismiss() }
            }
            Button("Отмена", role: .cancel) {}
        }
    }

    private func exerciseCard(index: Int) -> some View {
        let exercise = store.state.active?.exercises[index]
        let suggestion = store.progressionHint(for: exercise?.name ?? "")
        return Group {
            if let exercise {
                PaperCard {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(exercise.name)
                                .fontWeight(.semibold)
                                .foregroundColor(LiftTheme.text(store.state.settings.theme))
                            Spacer()
                            if exercise.supersetId != nil {
                                Text("суперсет").font(.caption).foregroundColor(.secondary)
                            }
                        }
                        if let last = store.lastWeight(for: exercise.name) {
                            Text("Прошлый раз: \(last) кг")
                                .font(.caption).foregroundColor(.secondary)
                        }
                        if let s = suggestion {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Пора повышать вес")
                                    .font(.caption.weight(.bold))
                                    .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                                Text("\(formatWeight(s.previousWeight)) → \(formatWeight(s.suggestedWeight)) кг · \(s.targetReps) повт.")
                                    .font(.caption)
                                Button("Применить") { store.applyProgression(s) }
                                    .buttonStyle(.bordered)
                            }
                        }
                        ForEach(Array(exercise.sets.indices), id: \.self) { setIndex in
                            HStack(spacing: 8) {
                                Text("\(setIndex + 1)").frame(width: 20)
                                TextField("кг", text: weightBinding(exIndex: index, setIndex: setIndex))
                                    .textFieldStyle(.roundedBorder)
                                    .keyboardType(.decimalPad)
                                    .frame(width: 80)
                                Text("×")
                                TextField("повт", text: repsBinding(exIndex: index, setIndex: setIndex))
                                    .textFieldStyle(.roundedBorder)
                                    .keyboardType(.numberPad)
                                    .frame(width: 60)
                                Button {
                                    toggleSet(exIndex: index, setIndex: setIndex, superset: exercise.supersetId != nil)
                                } label: {
                                    Image(systemName: exercise.sets[setIndex].done ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(exercise.sets[setIndex].done ? LiftTheme.accent(store.state.settings.accent) : .secondary)
                                }
                                .buttonStyle(.borderless)
                            }
                        }
                        HStack {
                            Button("Подход") { addSet(index) }.buttonStyle(.borderless)
                            Button("Убрать подход", role: .destructive) { removeSet(index) }.buttonStyle(.borderless)
                            Spacer()
                            Button(role: .destructive) { removeExercise(index) } label: {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                }
            }
        }
    }

    private func weightBinding(exIndex: Int, setIndex: Int) -> Binding<String> {
        Binding(
            get: { store.state.active?.exercises[exIndex].sets[setIndex].weight ?? "" },
            set: { newValue in
                guard var active = store.state.active else { return }
                active.exercises[exIndex].sets[setIndex].weight = newValue
                store.state.active = active
                store.save()
            }
        )
    }

    private func repsBinding(exIndex: Int, setIndex: Int) -> Binding<String> {
        Binding(
            get: { store.state.active?.exercises[exIndex].sets[setIndex].reps ?? "" },
            set: { newValue in
                guard var active = store.state.active else { return }
                active.exercises[exIndex].sets[setIndex].reps = newValue
                store.state.active = active
                store.save()
            }
        )
    }

    private func toggleSet(exIndex: Int, setIndex: Int, superset: Bool) {
        guard var active = store.state.active else { return }
        active.exercises[exIndex].sets[setIndex].done.toggle()
        store.state.active = active
        store.save()
        if active.exercises[exIndex].sets[setIndex].done {
            restNext = active.exercises.count > exIndex + 1 ? active.exercises[exIndex + 1].name : nil
            startRest(seconds: superset ? store.state.settings.shortRestSeconds : store.state.settings.restSeconds)
        }
    }

    private func addSet(_ index: Int) {
        guard var active = store.state.active else { return }
        let first = active.exercises[index].sets.first
        active.exercises[index].sets.append(ActiveSet(
            weight: first?.weight ?? "", reps: first?.reps ?? "10"
        ))
        store.state.active = active
        store.save()
    }

    private func removeSet(_ index: Int) {
        guard var active = store.state.active, !active.exercises[index].sets.isEmpty else { return }
        active.exercises[index].sets.removeLast()
        store.state.active = active
        store.save()
    }

    private func removeExercise(_ index: Int) {
        guard var active = store.state.active else { return }
        active.exercises.remove(at: index)
        store.state.active = active
        store.save()
    }

    private func startRest(seconds: Int) {
        restLeft = seconds
        restTotal = seconds
        ReminderManager.shared.scheduleRestTimer(seconds: seconds)
    }

    private func cancelRest() {
        restLeft = 0
        ReminderManager.shared.cancelRestTimer()
    }
}

/// Выбор упражнения для добавления в текущую тренировку.
struct CatalogPickView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State private var search = ""

    private var items: [Exercise] {
        search.isEmpty ? store.exercises : store.exercises.filter { $0.name.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        List {
            TextField("Поиск", text: $search)
            ForEach(items) { ex in
                Button {
                    guard var active = store.state.active else { return }
                    active.exercises.append(ActiveExercise(
                        name: ex.name, group: ex.group,
                        sets: [ActiveSet(weight: store.lastWeight(for: ex.name) ?? "", reps: "10")]
                    ))
                    store.state.active = active
                    store.save()
                    dismiss()
                } label: {
                    VStack(alignment: .leading) {
                        Text(ex.name)
                        Text(ex.group).font(.caption).foregroundColor(.secondary)
                    }
                }
            }
        }
        .navigationTitle("Добавить упражнение")
    }
}
