import SwiftUI

struct MoreView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        List {
            Section {
                NavigationLink("Прогресс") { ProgressStatsView() }
                NavigationLink("Калькулятор 1ПМ") { CalculatorView() }
                NavigationLink("Напоминания") { RemindersView() }
                NavigationLink("Оформление") { InterfaceSettingsView() }
            }
            Section {
                NavigationLink("Настройки") { SettingsView() }
            }
            Section {
                Text("LiftBook 2.3 · \(store.exercises.count) упражнений")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .navigationTitle("Ещё")
    }
}

// MARK: - Прогресс

struct ProgressStatsView: View {
    @EnvironmentObject var store: Store
    @State private var search = ""
    @State private var selected: String? = nil

    private var names: [String] {
        Array(Set(store.state.history.flatMap { $0.exercises.map(\.name) })).sorted()
    }

    private var filteredNames: [String] {
        search.isEmpty ? names : names.filter { $0.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: "Прогресс", subtitle: "Графики по упражнениям")
                TextField("Поиск упражнения", text: $search).textFieldStyle(.roundedBorder)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(filteredNames, id: \.self) { name in
                            Button(name) { selected = name }
                                .buttonStyle(.bordered)
                                .tint(name == selected ? LiftTheme.accent(store.state.settings.accent) : .gray)
                        }
                    }
                }
                if let name = selected {
                    let points = progressPoints(history: store.state.history, name: name)
                    PaperCard {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(name).font(.headline)
                            if let first = points.first, let last = points.last {
                                Text("Рекорд: \(formatWeight(last.weight)) кг · \(points.count) сессий")
                                    .font(.subheadline)
                                Text("Прирост: \(formatWeight(last.weight - first.weight)) кг")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            // Простой столбчатый график
                            HStack(alignment: .bottom, spacing: 4) {
                                ForEach(points.suffix(20), id: \.date) { point in
                                    VStack {
                                        Spacer()
                                        Rectangle()
                                            .fill(LiftTheme.accent(store.state.settings.accent))
                                            .frame(width: 12, height: max(4, CGFloat(point.weight / max(1, points.last?.weight ?? 1) * 90)))
                                    }
                                }
                            }
                            .frame(height: 100)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                } else {
                    EmptyState(title: "Выбери упражнение", message: "Нажми на название выше, чтобы увидеть прогресс веса.")
                }
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .navigationTitle("Прогресс")
    }
}

// MARK: - Калькулятор 1ПМ

struct CalculatorView: View {
    @EnvironmentObject var store: Store
    @State private var weight = "60"
    @State private var reps = "5"

    private var oneRepMax: Double? {
        guard let w = Double(weight.replacingOccurrences(of: ",", with: ".")), w > 0,
              let r = Int(reps), (1...30).contains(r) else { return nil }
        return roundHalf(w * (1.0 + Double(r) / 30.0))
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: "Калькулятор 1ПМ", subtitle: "Формула Эпли")
                PaperCard {
                    HStack {
                        TextField("Вес, кг", text: $weight).keyboardType(.decimalPad).textFieldStyle(.roundedBorder)
                        TextField("Повторы", text: $reps).keyboardType(.numberPad).textFieldStyle(.roundedBorder).frame(width: 90)
                    }
                }
                if let max = oneRepMax {
                    PaperCard {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("1ПМ: \(formatWeight(max)) кг")
                                .font(.title2.weight(.bold))
                                .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                            Text("Расчёт: \(weight) кг × (1 + \(reps) / 30)")
                                .font(.caption).foregroundColor(.secondary)
                            ForEach([100, 95, 90, 85, 80, 75, 70, 65], id: \.self) { percent in
                                HStack {
                                    Text("\(percent)%")
                                    Spacer()
                                    Text("\(formatWeight(roundHalf(max * Double(percent) / 100.0))) кг")
                                }
                                .font(.subheadline)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                } else {
                    Text("Введи вес больше 0 и от 1 до 30 повторений")
                        .foregroundColor(.red)
                        .font(.caption)
                }
                Text("Формула Эпли — оценочная. Реальный 1ПМ может отличаться.")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .navigationTitle("Калькулятор 1ПМ")
    }

    private func roundHalf(_ value: Double) -> Double { (value * 2).rounded() / 2 }
}

// MARK: - Напоминания

struct RemindersView: View {
    @EnvironmentObject var store: Store
    @ObservedObject private var manager = ReminderManager.shared
    @State private var showEditor = false
    @State private var editingId: Int64? = nil
    @State private var text = ""
    @State private var hour = 9
    @State private var minute = 0

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: "Напоминания", subtitle: "Каждый день в выбранное время")
                if !manager.notificationsAuthorized {
                    PaperCard {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Уведомления выключены")
                                .fontWeight(.semibold)
                            Text("Разреши уведомления, чтобы напоминания приходили, когда приложение свёрнуто.")
                                .font(.caption).foregroundColor(.secondary)
                            Button("Разрешить уведомления") {
                                manager.requestAuthorization(reminders: store.state.reminders)
                            }
                                .buttonStyle(.borderedProminent)
                                .tint(LiftTheme.accent(store.state.settings.accent))
                        }
                    }
                }
                if store.state.reminders.isEmpty {
                    EmptyState(title: "Пока нет напоминаний", message: "Например: «Выпить креатин» каждый день в 09:00. Текст придумываешь сам.")
                } else {
                    ForEach(store.state.reminders) { reminder in
                        PaperCard {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(reminder.text).fontWeight(.semibold)
                                    Text("Каждый день · \(reminder.timeLabel)\(reminder.enabled ? "" : " · выключено")")
                                        .font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                Toggle("", isOn: Binding(
                                    get: { reminder.enabled },
                                    set: { store.setReminderEnabled(reminder.id, enabled: $0) }
                                )).labelsHidden()
                                Button { edit(reminder) } label: { Image(systemName: "pencil") }
                                    .buttonStyle(.borderless)
                                Button(role: .destructive) { store.removeReminder(reminder.id) } label: {
                                    Image(systemName: "trash")
                                }
                                .buttonStyle(.borderless)
                            }
                        }
                    }
                }
                AccentButton(title: "Добавить напоминание") { showEditor = true }
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .navigationTitle("Напоминания")
        .sheet(isPresented: $showEditor) {
            NavigationStack {
                Form {
                    Section("Текст") {
                        TextField("Например: Выпить креатин", text: $text)
                    }
                    Section("Время") {
                        DatePicker("Время", selection: Binding(
                            get: {
                                var c = Calendar.current.dateComponents([.hour, .minute], from: Date())
                                c.hour = hour; c.minute = minute
                                return Calendar.current.date(from: c) ?? Date()
                            },
                            set: { date in
                                let c = Calendar.current.dateComponents([.hour, .minute], from: date)
                                hour = c.hour ?? 9; minute = c.minute ?? 0
                            }
                        ), displayedComponents: .hourAndMinute)
                        HStack {
                            ForEach(["08:00", "12:00", "18:00", "21:30"], id: \.self) { time in
                                Button(time) {
                                    let parts = time.split(separator: ":").map(String.init)
                                    hour = Int(parts.first ?? "9") ?? 9
                                    minute = Int(parts.last ?? "0") ?? 0
                                }
                                .buttonStyle(.bordered)
                            }
                        }
                    }
                }
                .navigationTitle(editingId == nil ? "Новое напоминание" : "Изменить напоминание")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Отмена") { showEditor = false } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Сохранить") {
                            if let id = editingId {
                                store.updateReminder(id: id, text: text, hour: hour, minute: minute)
                            } else {
                                store.addReminder(text: text, hour: hour, minute: minute)
                            }
                            showEditor = false
                        }
                        .disabled(text.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                }
            }
        }
        .onAppear { manager.refreshAuthorization() }
    }

    private func edit(_ reminder: Reminder) {
        editingId = reminder.id
        text = reminder.text
        hour = reminder.hour
        minute = reminder.minute
        showEditor = true
    }
}

// MARK: - Настройки

struct SettingsView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        List {
            Section {
                NavigationLink("Интерфейс и отдых") { InterfaceSettingsView() }
                NavigationLink("Напоминания") { RemindersView() }
            }
            Section("Таймеры отдыха") {
                StepperRow(title: "Короткий отдых", value: formatTimer(Int64(store.state.settings.shortRestSeconds) * 1000),
                           decrease: { store.setShortRestSeconds(store.state.settings.shortRestSeconds - 15) },
                           increase: { store.setShortRestSeconds(store.state.settings.shortRestSeconds + 15) })
                StepperRow(title: "Длинный отдых", value: formatTimer(Int64(store.state.settings.restSeconds) * 1000),
                           decrease: { store.setRestSeconds(store.state.settings.restSeconds - 15) },
                           increase: { store.setRestSeconds(store.state.settings.restSeconds + 15) })
            }
            Section("Экспорт") {
                Toggle("Только код LIFTBOOK1:", isOn: Binding(
                    get: { store.state.settings.shareCodeOnly },
                    set: { store.setShareCodeOnly($0) }
                ))
                Text("Если включено, «Поделиться» отправляет только код обмена.")
                    .font(.caption).foregroundColor(.secondary)
            }
            Section {
                Text("Дневник тренировок · версия 2.3")
                    .font(.caption).foregroundColor(.secondary)
            }
        }
        .navigationTitle("Настройки")
    }
}

// MARK: - Оформление

struct InterfaceSettingsView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        Form {
            Section("Тема") {
                Picker("Тема приложения", selection: Binding(
                    get: { store.state.settings.theme },
                    set: { store.setTheme($0) }
                )) {
                    ForEach(ThemeMode.allCases, id: \.self) { Text($0.label).tag($0) }
                }
                Text(store.state.settings.theme.description)
                    .font(.caption).foregroundColor(.secondary)
            }
            Section("Чернила") {
                Picker("Цвет чернил", selection: Binding(
                    get: { store.state.settings.inkColor },
                    set: { store.setInkColor($0) }
                )) {
                    ForEach(HandInkColor.allCases, id: \.self) { Text($0.label).tag($0) }
                }
            }
            Section("Акцент") {
                Picker("Акцентный цвет", selection: Binding(
                    get: { store.state.settings.accent },
                    set: { store.setAccent($0) }
                )) {
                    ForEach(Accent.allCases, id: \.self) { Text($0.label).tag($0) }
                }
            }
            Section("Предпросмотр") {
                PaperCard {
                    Text("Твой дневник тренировок")
                        .font(.custom(LiftTheme.fontName(store.state.settings.theme) ?? "System", size: 22))
                        .foregroundColor(LiftTheme.text(store.state.settings.theme))
                }
            }
            Section {
                Button("Сбросить настройки") {
                    store.setTheme(.light)
                    store.setInkColor(.blue)
                    store.setAccent(.lime)
                    store.setRestSeconds(150)
                    store.setShortRestSeconds(60)
                    store.setShareCodeOnly(false)
                }
            }
        }
        .navigationTitle("Оформление")
    }
}
