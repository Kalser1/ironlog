import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: Store
    @Environment(\.scenePhase) var scenePhase

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                ScreenHeader(
                    title: "LiftBook",
                    subtitle: formatLongDate(Periodization.nowMs())
                )

                if store.state.active != nil {
                    PaperCard {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("ТРЕНИРОВКА ИДЁТ")
                                .font(.caption.weight(.bold))
                                .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                            Text("В работе \(pluralExercises(store.state.active?.exercises.count ?? 0)) — не теряй настрой")
                                .font(.subheadline)
                                .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                            NavigationLink(value: Route.workout) {
                                Text("Продолжить")
                                    .fontWeight(.semibold)
                            }
                        }
                    }
                }

                HStack(spacing: 12) {
                    statCard(title: "Тренировок", value: "\(store.state.history.count)")
                    statCard(title: "Объём за 7 дней", value: volume7d)
                }

                if store.state.active == nil {
                    AccentButton(title: "Начать тренировку") {
                        store.startWorkout()
                    }
                }

                Text("Быстрый доступ")
                    .font(.custom(LiftTheme.fontName(store.state.settings.theme) ?? "System", size: 22))
                    .foregroundColor(LiftTheme.text(store.state.settings.theme))

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    quickCard("Каталог", "\(store.exercises.count) упр.", systemImage: "book") { AnyView(CatalogView()) }
                    quickCard("Программы", "\(pluralPrograms(store.state.programs.count))", systemImage: "square.stack.3d.up") { AnyView(ProgramsView()) }
                    quickCard("История", "\(pluralWorkouts(store.state.history.count))", systemImage: "clock.arrow.circlepath") { AnyView(HistoryView()) }
                    quickCard("Прогресс", "графики", systemImage: "chart.line.uptrend.xyaxis") { AnyView(ProgressStatsView()) }
                }

                if let last = store.state.history.first {
                    Text("Последняя тренировка")
                        .font(.custom(LiftTheme.fontName(store.state.settings.theme) ?? "System", size: 22))
                        .foregroundColor(LiftTheme.text(store.state.settings.theme))
                    NavigationLink(value: Route.historyDetail(last.id)) {
                        PaperCard {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(formatDate(last.finishedAt))
                                    .fontWeight(.semibold)
                                    .foregroundColor(LiftTheme.text(store.state.settings.theme))
                                Text("\(pluralExercises(last.exercises.count)) · \(pluralSets(last.totalSets)) · \(formatDuration(last.durationMs))")
                                    .font(.subheadline)
                                    .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding()
        }
        .background(LiftTheme.paper(store.state.settings.theme).ignoresSafeArea())
        .navigationDestination(for: Route.self) { route in
            route.destination
        }
    }

    private var volume7d: String {
        let threshold = Periodization.nowMs() - 7 * Periodization.dayMs
        return formatVolume(store.state.history.filter { $0.finishedAt >= threshold }.reduce(0) { $0 + $1.volume })
    }

    private func statCard(title: String, value: String) -> some View {
        PaperCard {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                Text(value)
                    .font(.custom(LiftTheme.fontName(store.state.settings.theme) ?? "System", size: 24))
                    .foregroundColor(LiftTheme.text(store.state.settings.theme))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func quickCard<Destination: View>(
        _ title: String, _ subtitle: String, systemImage: String,
        @ViewBuilder destination: () -> Destination
    ) -> some View {
        NavigationLink {
            destination()
        } label: {
            PaperCard {
                VStack(alignment: .leading, spacing: 8) {
                    Image(systemName: systemImage)
                        .font(.title2)
                        .foregroundColor(LiftTheme.accent(store.state.settings.accent))
                    Text(title)
                        .fontWeight(.semibold)
                        .foregroundColor(LiftTheme.text(store.state.settings.theme))
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(LiftTheme.secondaryText(store.state.settings.theme))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .buttonStyle(.plain)
    }
}

enum Route: Hashable {
    case workout
    case programDetail(Int64)
    case historyDetail(Int64)
    case exerciseDetail(String)

    @ViewBuilder
    var destination: some View {
        switch self {
        case .workout: WorkoutView()
        case .programDetail(let id): ProgramDetailView(programId: id)
        case .historyDetail(let id): HistoryDetailView(workoutId: id)
        case .exerciseDetail(let name): ExerciseDetailView(name: name)
        }
    }
}
